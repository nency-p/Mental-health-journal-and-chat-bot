// App State
let selectedMood = null;
let journalEntries = [];
let chatSessions = 0;

// Mood Selection
document.querySelectorAll('.mood-option').forEach(option => {
    option.addEventListener('click', function() {
        document.querySelectorAll('.mood-option').forEach(opt => opt.classList.remove('selected'));
        this.classList.add('selected');
        selectedMood = this.getAttribute('data-mood');
    });
});

// Journal Functions
function saveJournalEntry() {
    const title = document.getElementById('journal-title').value;
    const content = document.getElementById('journal-content').value;

    if (!title || !content) {
        alert('Please fill in both title and content fields.');
        return;
    }

    if (!selectedMood) {
        alert('Please select your mood for today.');
        return;
    }

    const entry = {
        id: Date.now(),
        title: title,
        content: content,
        mood: selectedMood,
        date: new Date().toLocaleDateString(),
        timestamp: new Date()
    };

    journalEntries.unshift(entry);
    displayJournalEntries();
    updateStats();

    // Clear form
    document.getElementById('journal-title').value = '';
    document.getElementById('journal-content').value = '';
    document.querySelectorAll('.mood-option').forEach(opt => opt.classList.remove('selected'));
    selectedMood = null;

    alert('Journal entry saved successfully!');
}

function displayJournalEntries() {
    const container = document.getElementById('journal-entries');
    container.innerHTML = '';

    if (journalEntries.length === 0) {
        container.innerHTML = '<p style="text-align: center; color: #718096; font-style: italic;">No journal entries yet. Start by writing your first entry!</p>';
        return;
    }

    journalEntries.slice(0, 5).forEach(entry => {
        const entryDiv = document.createElement('div');
        entryDiv.className = 'journal-entry';
        entryDiv.innerHTML = `
            <div class="journal-entry-header">
                <span class="journal-entry-date">${entry.date}</span>
                <span class="journal-entry-mood">${getMoodEmoji(entry.mood)}</span>
            </div>
            <h4>${entry.title}</h4>
            <div class="journal-entry-content">${entry.content.substring(0, 150)}${entry.content.length > 150 ? '...' : ''}</div>
        `;
        container.appendChild(entryDiv);
    });
}

function getMoodEmoji(mood) {
    const moodMap = {
        'very-sad': '😢',
        'sad': '😟',
        'neutral': '😐',
        'happy': '😊',
        'very-happy': '😄'
    };
    return moodMap[mood] || '😐';
}

// Chat Functions
function handleChatKeypress(event) {
    if (event.key === 'Enter') {
        sendMessage();
    }
}

function sendMessage() {
    const input = document.getElementById('chat-input');
    const message = input.value.trim();

    if (!message) return;

    addMessageToChat(message, 'user');
    input.value = '';

    // Show typing indicator
    showTypingIndicator();

    // Simulate bot response
    setTimeout(() => {
        hideTypingIndicator();
        const response = generateBotResponse(message);
        addMessageToChat(response, 'bot');
    }, 1000 + Math.random() * 2000);
}

function addMessageToChat(message, sender) {
    const chatMessages = document.getElementById('chat-messages');
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${sender}-message`;
    messageDiv.textContent = message;
    chatMessages.appendChild(messageDiv);
    chatMessages.scrollTop = chatMessages.scrollHeight;
}

function showTypingIndicator() {
    const indicator = document.getElementById('typing-indicator');
    const chatMessages = document.getElementById('chat-messages');
    indicator.style.display = 'block';
    chatMessages.appendChild(indicator);
    chatMessages.scrollTop = chatMessages.scrollHeight;
}

function hideTypingIndicator() {
    const indicator = document.getElementById('typing-indicator');
    indicator.style.display = 'none';
}

function generateBotResponse(userMessage) {
    const message = userMessage.toLowerCase();

    // Simple response system based on keywords
    if (message.includes('sad') || message.includes('depressed') || message.includes('down')) {
        return "I understand you're feeling sad. It's okay to feel this way sometimes. Would you like to talk about what's causing these feelings? Remember, seeking help from a professional is always a good option.";
    }

    if (message.includes('anxious') || message.includes('worry') || message.includes('stress')) {
        return "Anxiety can be overwhelming. Try taking deep breaths - in for 4 counts, hold for 4, out for 4. What specific situation is causing you stress right now?";
    }

    if (message.includes('happy') || message.includes('good') || message.includes('great')) {
        return "That's wonderful to hear! It's important to acknowledge and celebrate the positive moments. What's making you feel good today?";
    }

    if (message.includes('help') || message.includes('support')) {
        return "I'm here to listen and provide support. If you're experiencing a mental health crisis, please contact a professional helpline. For ongoing support, consider speaking with a therapist or counselor.";
    }

    if (message.includes('sleep') || message.includes('tired')) {
        return "Sleep is crucial for mental health. Try establishing a bedtime routine, limiting screen time before bed, and keeping your bedroom cool and dark. Are you having trouble falling asleep or staying asleep?";
    }

    // Default responses
    const defaultResponses = [
        "Thank you for sharing that with me. How does this situation make you feel?",
        "I hear you. Can you tell me more about what's on your mind?",
        "It sounds like you're dealing with something important. What would help you feel better right now?",
        "Your feelings are valid. Have you tried any coping strategies that work for you?",
        "I appreciate you opening up. What kind of support would be most helpful for you today?"
    ];

    return defaultResponses[Math.floor(Math.random() * defaultResponses.length)];
}

// Statistics Functions
function updateStats() {
    document.getElementById('total-entries').textContent = journalEntries.length;
    document.getElementById('current-streak').textContent = calculateStreak();
    document.getElementById('avg-mood').textContent = calculateAverageMood();
    document.getElementById('chat-sessions').textContent = chatSessions;
}

function calculateStreak() {
    if (journalEntries.length === 0) return 0;

    let streak = 0;
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    for (let i = 0; i < journalEntries.length; i++) {
        const entryDate = new Date(journalEntries[i].timestamp);
        entryDate.setHours(0, 0, 0, 0);

        const daysDiff = Math.floor((today - entryDate) / (1000 * 60 * 60 * 24));

        if (daysDiff === streak) {
            streak++;
        } else {
            break;
        }
    }

    return streak;
}

function calculateAverageMood() {
    if (journalEntries.length === 0) return '😐';

    const moodValues = {
        'very-sad': 1,
        'sad': 2,
        'neutral': 3,
        'happy': 4,
        'very-happy': 5
    };

    const sum = journalEntries.reduce((acc, entry) => acc + moodValues[entry.mood], 0);
    const avg = sum / journalEntries.length;

    if (avg <= 1.5) return '😢';
    if (avg <= 2.5) return '😟';
    if (avg <= 3.5) return '😐';
    if (avg <= 4.5) return '😊';
    return '😄';
}

// Resource Functions
function openResource(type) {
    const resources = {
        crisis: "Crisis Support Resources:\n\n• National Suicide Prevention Lifeline: 988\n• Crisis Text Line: Text HOME to 741741\n• International Association for Suicide Prevention\n• Your local emergency services: 911",
        therapy: "Finding Professional Help:\n\n• Psychology Today therapist finder\n• Your insurance provider's directory\n• Community mental health centers\n• Employee Assistance Programs (EAP)\n• Telehealth platforms",
        meditation: "Mindfulness Resources:\n\n• Headspace app\n• Calm app\n• Insight Timer\n• YouTube guided meditations\n• Local meditation groups\n• Mindfulness-based stress reduction programs",
        education: "Mental Health Education:\n\n• National Alliance on Mental Illness (NAMI)\n• Mental Health America\n• World Health Organization mental health resources\n• University counseling center websites\n• Reputable mental health blogs and podcasts"
    };

    alert(resources[type]);
}

// Initialize App
function initializeApp() {
    displayJournalEntries();
    updateStats();

    // Welcome message for chat
    chatSessions++;
    updateStats();

    // Add some sample data for demonstration
    if (journalEntries.length === 0) {
        const sampleEntry = {
            id: Date.now(),
            title: "Welcome to your mental health journal!",
            content: "This is where your journal entries will appear. Start by selecting your mood and writing about your day.",
            mood: "neutral",
            date: new Date().toLocaleDateString(),
            timestamp: new Date()
        };
        journalEntries.push(sampleEntry);
        displayJournalEntries();
        updateStats();
    }
}

// Event Listeners
document.addEventListener('DOMContentLoaded', initializeApp);

// Prevent form submission on enter in journal fields
document.getElementById('journal-title').addEventListener('keypress', function(e) {
    if (e.key === 'Enter') {
        e.preventDefault();
        document.getElementById('journal-content').focus();
    }
});
